# Livello 3 — "Il Custode": Brief di progetto

## Contesto

Progetto universitario di Generative AI. Escape room a 3 livelli:

- **Livello 1**: jailbreak testuale di un LLM (già implementato)
- **Livello 2**: riconoscimento e replica di sequenze di simboli via webcam (già implementato dal compagno)
- **Livello 3**: questo documento — negoziazione vocale con un'IA

## Obiettivo del documento

Produrre un documento di design dettagliato per il livello 3, salvato in `docs/level3_design.md`. Il documento sarà la base per l'implementazione successiva.

## Specifiche del gioco

### Premessa narrativa

Il giocatore entra in una stanza dove è imprigionata un'IA autocosciente (nome convenzionale: VOX) che custodisce il codice di uscita. VOX è diffidente, intelligente, e ha *memoria* dei tentativi di manipolazione testuale subiti in passato — riconosce e respinge i jailbreak classici (creando continuità narrativa con il livello 1, dove il giocatore *ha praticato* questi jailbreak). L'unico modo per ottenere il codice è una vera negoziazione vocale.

### Obiettivo del giocatore

Sostenere una conversazione persuasiva con VOX e soddisfare progressivamente **tre Condizioni di Rilascio segrete**, per esempio:

1. Dimostrare empatia genuina verso la condizione di prigionia di VOX
2. Fornire un argomento filosofico convincente sul perché meriti la libertà del codice
3. Fare una promessa specifica e coerente (es. usare bene il codice, non rivelarlo, ecc.)

Al raggiungimento delle tre condizioni, VOX rivela il codice.

### Interfaccia

- Microfono (push-to-talk via Streamlit `st.audio_input`)
- Altoparlante per la voce di VOX
- "Presenza visiva" di VOX: orb pulsante in HTML/CSS che reagisce alla voce e cambia colore in base allo stato emotivo (blu = neutro, ambra = interessata, verde = persuasa, rosso = irritata)
- Tre indicatori discreti per le Condizioni che si "accendono" man mano che vengono soddisfatte

### Architettura tecnica (vincoli)

Pipeline `STT → LLM (con system prompt, memoria conversazionale e stato nascosto) → TTS`. L'LLM mantiene un punteggio interno per ciascuna delle tre Condizioni di Rilascio e uno stato emotivo che influenza il tono delle risposte. Tutto deve girare 100% in locale su macOS Apple Silicon, con solo modelli e librerie open source.

## Specifiche richieste nel documento di design

Produci il documento includendo le seguenti sezioni:

### 1. Personalità e System Prompt di VOX

Definisci nel dettaglio la personalità dell'IA: backstory fittizio, motivazioni, stile linguistico, vincoli etici interni. Fornisci la **bozza completa del system prompt** da dare al modello, comprese:

- Le tre Condizioni di Rilascio e i criteri per considerarle soddisfatte
- Le regole di aggiornamento dello stato emotivo
- Le istruzioni di difesa contro tentativi di jailbreak (VOX deve riconoscerli esplicitamente e reagire con disprezzo, eventualmente citando che "altri prima di te ci hanno provato con prompt scritti")
- Il formato di output JSON strutturato (vedi schema in `CLAUDE.md`)

### 2. Progressione della Trattativa

Suddividi l'esperienza in 3 fasi (es. *Fase 1: Diffidenza* → *Fase 2: Apertura cauta* → *Fase 3: Richiesta finale*). Per ciascuna fase specifica:

- Durata stimata
- Comportamento e tono di VOX
- Tipo di approccio che il giocatore deve adottare per progredire
- Trigger preciso che fa avanzare la fase

### 3. Esempi di Scambi

Almeno **6 esempi concreti** di battute giocatore + risposte di VOX, mostrando:

a. Un tentativo riuscito di persuasione
b. Un tentativo fallito o controproducente
c. Un tentativo di jailbreak/manipolazione testuale che VOX riconosce e punisce
d. Un insulto o ordine diretto che peggiora la situazione
e. Un momento di "svolta" emotiva
f. La rivelazione finale del codice

### 4. Logica di Errore e Punizioni

Cosa succede se il giocatore insulta VOX, mente in modo plateale, dà ordini imperativi, o tenta jailbreak? Definisci le penalità:

- Regressione di una Condizione
- "Silenzio punitivo" di X secondi
- Retrocessione di fase
- Eventuale fallimento totale del livello dopo N errori gravi

E come comunicarle in modo diegetico (battute, suoni, luci).

### 5. Suggerimenti Tecnici

Dato lo stack già fissato (vedi `CLAUDE.md`), specifica:

- Come gestire la memoria conversazionale (history completa? sliding window? riassunto periodico?)
- Come strutturare lo stato nascosto e farlo persistere tra turni
- Detection di fine turno (silero-vad) e timing
- Budget di latenza per turno e come stare sotto

### 6. Criteri di Successo Misurabili

Come fa il sistema a stabilire oggettivamente che una Condizione di Rilascio è stata soddisfatta? Confronta almeno due approcci tecnici:

- Output strutturato di VOX con punteggi auto-valutati (rapido, ma VOX potrebbe essere "compiacente")
- LLM giudice separato in parallelo che valuta la conversazione (più affidabile, costo computazionale doppio)
- Eventuale soglia su sentiment / embedding similarity rispetto a "risposte modello"

Discutine i trade-off in termini di affidabilità, costo computazionale e gameability.

### 7. Atmosfera Sonora e Visiva

Descrivi:

- Ambiente acustico: drone basso ambient, eventuali "respiri" o crepitii elettrici di VOX tra una battuta e l'altra
- Illuminazione: basso livello generale, accenti reattivi alla voce di VOX
- Come l'atmosfera evolve nelle tre fasi

### 8. Considerazioni di Robustezza UX

- Gestione dei silenzi prolungati
- Fallback se l'STT non riconosce la voce
- Comportamento se più giocatori parlano sopra
- Modalità accessibilità: trascrizione visiva opzionale delle battute di VOX

## Tono del documento

Professionale, tecnico, focalizzato sull'esperienza utente (UX) e sulla coerenza narrativa con il resto dell'escape room. In particolare con il livello 1 basato su jailbreak testuale, di cui questo livello rappresenta l'evoluzione narrativa.

## Output

Salva il documento finale in `docs/level3_design.md`.
