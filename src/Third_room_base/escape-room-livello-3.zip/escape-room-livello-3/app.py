"""
Escape Room - Livello 3: "Il Custode"

Entry point dell'applicazione Streamlit.

Stato attuale: SLICE 1 (skeleton). Mostra solo l'interfaccia base.
I prossimi slice aggiungeranno STT, LLM, TTS e visualizzazione di VOX.

Eseguire con:
    streamlit run app.py
"""
from __future__ import annotations

import logging

import streamlit as st
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger(__name__)


def main() -> None:
    st.set_page_config(
        page_title="Il Custode",
        page_icon="🔒",
        layout="centered",
    )

    st.title("🔒 Il Custode")
    st.caption("Escape Room — Livello 3 · Negoziazione vocale con un'IA carceriera")

    st.info(
        "**Slice 1 — Skeleton.** "
        "L'interfaccia di base è in piedi. I prossimi step aggiungeranno "
        "registrazione vocale, trascrizione, dialogo con VOX e sintesi vocale."
    )

    st.markdown("---")
    st.markdown(
        """
        ### Come funzionerà

        Davanti a te c'è VOX, un'IA che custodisce il codice di uscita.
        Per ottenerlo dovrai **convincerla** parlando.

        Niente forza, niente trucchi testuali. Solo dialogo.
        """
    )

    if st.button("Inizia la trattativa (placeholder)", type="primary", disabled=True):
        st.toast("Funzionalità in arrivo nello slice 2.")


if __name__ == "__main__":
    main()
